package com.xcape.dashboard.data

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Emits magnetic compass heading in degrees [0, 360), using the fused
 * ROTATION_VECTOR sensor when available and falling back to
 * accelerometer + magnetometer on older/cheaper hardware.
 */
class CompassRepository(private val context: Context) {

    fun headingUpdates(): Flow<Float> = callbackFlow {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        val rotationMatrix = FloatArray(9)
        val orientation = FloatArray(3)
        var lastAccel: FloatArray? = null
        var lastMag: FloatArray? = null

        fun emitFromRotationMatrix() {
            SensorManager.getOrientation(rotationMatrix, orientation)
            val azimuthRad = orientation[0]
            var degrees = Math.toDegrees(azimuthRad.toDouble()).toFloat()
            if (degrees < 0f) degrees += 360f
            trySend(degrees)
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                when (event.sensor.type) {
                    Sensor.TYPE_ROTATION_VECTOR -> {
                        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                        emitFromRotationMatrix()
                    }

                    Sensor.TYPE_ACCELEROMETER -> {
                        lastAccel = event.values.clone()
                        maybeEmitFallback()
                    }

                    Sensor.TYPE_MAGNETIC_FIELD -> {
                        lastMag = event.values.clone()
                        maybeEmitFallback()
                    }
                }
            }

            fun maybeEmitFallback() {
                if (rotationSensor != null) return // already using the better sensor
                val accel = lastAccel ?: return
                val mag = lastMag ?: return
                val success = SensorManager.getRotationMatrix(rotationMatrix, null, accel, mag)
                if (success) emitFromRotationMatrix()
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        if (rotationSensor != null) {
            sensorManager.registerListener(listener, rotationSensor, SensorManager.SENSOR_DELAY_UI)
        } else {
            accelerometer?.let {
                sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI)
            }
            magnetometer?.let {
                sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI)
            }
        }

        awaitClose {
            sensorManager.unregisterListener(listener)
        }
    }
}
