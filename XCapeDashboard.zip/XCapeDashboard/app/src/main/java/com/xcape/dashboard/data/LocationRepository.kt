package com.xcape.dashboard.data

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Wraps the plain Android [LocationManager] (no Google Play Services dependency,
 * so this keeps working on aftermarket / screen-mirroring head units that may not
 * ship Play Services) and exposes GPS fixes as a cold [Flow].
 */
class LocationRepository(private val context: Context) {

    @SuppressLint("MissingPermission")
    fun locationUpdates(minIntervalMs: Long = 1000L, minDistanceM: Float = 0f): Flow<Location> =
        callbackFlow {
            val locationManager =
                context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    trySend(location)
                }

                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
                }

                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }

            val providers = mutableListOf<String>()
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                providers.add(LocationManager.GPS_PROVIDER)
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                providers.add(LocationManager.NETWORK_PROVIDER)
            }

            providers.forEach { provider ->
                runCatching {
                    locationManager.requestLocationUpdates(
                        provider,
                        minIntervalMs,
                        minDistanceM,
                        listener
                    )
                }
            }

            // Emit the last known fix immediately if we have one, so the UI
            // doesn't sit at zero while waiting for the next update.
            providers.firstNotNullOfOrNull { provider ->
                runCatching { locationManager.getLastKnownLocation(provider) }.getOrNull()
            }?.let { trySend(it) }

            awaitClose {
                locationManager.removeUpdates(listener)
            }
        }
}
