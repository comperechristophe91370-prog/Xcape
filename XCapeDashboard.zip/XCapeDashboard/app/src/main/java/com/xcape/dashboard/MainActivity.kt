package com.xcape.dashboard

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.core.view.WindowCompat
import com.xcape.dashboard.ui.DashboardScreen
import com.xcape.dashboard.ui.PermissionGate
import com.xcape.dashboard.ui.theme.XCapeDashboardTheme
import com.xcape.dashboard.viewmodel.DashboardViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: DashboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep the screen on and drawing edge-to-edge while mounted on the bike.
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            val state by viewModel.uiState.collectAsState()

            XCapeDashboardTheme(isNightMode = state.isNightMode) {
                PermissionGate {
                    LaunchedEffect(Unit) {
                        viewModel.startTracking()
                    }

                    DashboardScreen(
                        state = state,
                        onToggleRecording = viewModel::toggleGpxRecording,
                        onToggleNightMode = viewModel::toggleNightMode
                    )
                }
            }
        }
    }
}
