package com.xcape.dashboard.ui.theme

import androidx.compose.ui.graphics.Color

// ---- Day palette (high contrast for direct sunlight) ----
val DayBackground = Color(0xFF101214)
val DaySurface = Color(0xFF1B1E22)
val DayOnSurface = Color(0xFFF5F5F5)
val DayAccent = Color(0xFFFF7A00) // Morini-inspired orange
val DayAccentSecondary = Color(0xFF3DA5FF)
val DayWarning = Color(0xFFFF4444)
val DayDim = Color(0xFF8A8F98)

// ---- Night palette (red-dominant, preserves night vision like BMW GS TFT) ----
val NightBackground = Color(0xFF000000)
val NightSurface = Color(0xFF120404)
val NightOnSurface = Color(0xFFFF3B30)
val NightAccent = Color(0xFFFF5A3C)
val NightAccentSecondary = Color(0xFFB33A2E)
val NightWarning = Color(0xFFFF2A2A)
val NightDim = Color(0xFF7A2A22)
