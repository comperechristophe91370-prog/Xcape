package com.xcape.dashboard.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xcape.dashboard.ui.theme.DashboardTheme

/**
 * Oversized round touch targets (72dp+) with high-contrast icons, designed
 * to be operable with full-finger motorcycle gloves and imprecise taps.
 */
@Composable
fun GpxControlBar(
    isRecording: Boolean,
    gpxPointCount: Int,
    isNightMode: Boolean,
    onToggleRecording: () -> Unit,
    onToggleNightMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = DashboardTheme.colors

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isRecording) {
            Text(
                text = "REC · $gpxPointCount pts",
                color = colors.warning,
                fontSize = 14.sp
            )
        }

        GloveButton(
            onClick = onToggleRecording,
            backgroundColor = if (isRecording) colors.warning else colors.surface,
            contentColor = if (isRecording) Color.White else colors.warning
        ) {
            Icon(
                imageVector = if (isRecording) Icons.Filled.Stop else Icons.Filled.FiberManualRecord,
                contentDescription = if (isRecording) "Stop GPX recording" else "Start GPX recording",
                modifier = Modifier.size(32.dp)
            )
        }

        GloveButton(
            onClick = onToggleNightMode,
            backgroundColor = colors.surface,
            contentColor = colors.accent
        ) {
            Icon(
                imageVector = if (isNightMode) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                contentDescription = "Toggle day/night mode",
                modifier = Modifier.size(32.dp)
            )
        }
    }
}

@Composable
private fun GloveButton(
    onClick: () -> Unit,
    backgroundColor: Color,
    contentColor: Color,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .size(76.dp)
            .background(backgroundColor, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        IconButton(
            onClick = onClick,
            modifier = Modifier.size(76.dp)
        ) {
            androidx.compose.runtime.CompositionLocalProvider(
                androidx.compose.material3.LocalContentColor provides contentColor
            ) {
                content()
            }
        }
    }
}
