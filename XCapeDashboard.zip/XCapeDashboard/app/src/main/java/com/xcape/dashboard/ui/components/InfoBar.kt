package com.xcape.dashboard.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Height
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.GpsNotFixed
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.xcape.dashboard.ui.theme.ClockTextStyle
import com.xcape.dashboard.ui.theme.DashboardTheme
import com.xcape.dashboard.ui.theme.InfoLabelTextStyle
import com.xcape.dashboard.ui.theme.InfoValueTextStyle

@Composable
fun InfoBar(
    altitudeM: Int,
    timeText: String,
    hasGpsFix: Boolean,
    gpsAccuracyM: Float,
    modifier: Modifier = Modifier
) {
    val colors = DashboardTheme.colors

    Row(
        modifier = modifier
            .background(colors.surface.copy(alpha = 0.85f), RoundedCornerShape(14.dp))
            .padding(horizontal = 18.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        InfoItem(
            icon = Icons.Filled.Height,
            label = "ALTITUDE",
            value = "${altitudeM} m",
            color = colors.onSurface
        )

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Schedule,
                    contentDescription = null,
                    tint = colors.dim,
                    modifier = Modifier.padding(end = 4.dp)
                )
                Text(text = timeText, style = ClockTextStyle, color = colors.onSurface)
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (hasGpsFix) Icons.Filled.GpsFixed else Icons.Filled.GpsNotFixed,
                contentDescription = null,
                tint = if (hasGpsFix) colors.accent else colors.warning
            )
            Text(
                text = if (hasGpsFix) "±${gpsAccuracyM.toInt()}m" else "NO FIX",
                style = InfoLabelTextStyle,
                color = if (hasGpsFix) colors.dim else colors.warning,
                modifier = Modifier.padding(start = 4.dp)
            )
        }
    }
}

@Composable
private fun InfoItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: androidx.compose.ui.graphics.Color
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = icon, contentDescription = null, tint = color)
        Column(modifier = Modifier.padding(start = 6.dp)) {
            Text(text = label, style = InfoLabelTextStyle, color = color.copy(alpha = 0.6f))
            Text(text = value, style = InfoValueTextStyle, color = color)
        }
    }
}
