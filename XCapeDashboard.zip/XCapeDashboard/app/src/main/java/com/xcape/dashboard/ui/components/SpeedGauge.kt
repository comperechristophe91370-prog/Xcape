package com.xcape.dashboard.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.xcape.dashboard.ui.theme.DashboardTheme
import com.xcape.dashboard.ui.theme.SpeedTextStyle
import com.xcape.dashboard.ui.theme.SpeedUnitTextStyle

/**
 * Big, BMW-GS-TFT-style numeric speed readout. Sized to be read at a glance
 * in peripheral vision, without needing to look away from the road.
 */
@Composable
fun SpeedGauge(
    speedKmh: Int,
    hasFix: Boolean,
    modifier: Modifier = Modifier
) {
    val colors = DashboardTheme.colors

    Column(
        modifier = modifier.padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = if (hasFix) speedKmh.toString() else "--",
                style = SpeedTextStyle,
                color = colors.onSurface,
                textAlign = TextAlign.Center
            )
        }
        Text(
            text = "KM/H",
            style = SpeedUnitTextStyle,
            color = colors.dim,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}
