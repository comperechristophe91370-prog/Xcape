package com.xcape.dashboard.viewmodel

import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.xcape.dashboard.data.CompassRepository
import com.xcape.dashboard.data.GpxRecorder
import com.xcape.dashboard.data.LocationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DashboardUiState(
    val speedKmh: Int = 0,
    val headingDeg: Float = 0f,
    val altitudeM: Int = 0,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val timeText: String = "--:--",
    val hasGpsFix: Boolean = false,
    val gpsAccuracyM: Float = 0f,
    val isNightMode: Boolean = false,
    val isRecording: Boolean = false,
    val gpxPointCount: Int = 0,
    val gpxFileName: String? = null
)

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val locationRepository = LocationRepository(application)
    private val compassRepository = CompassRepository(application)
    private val gpxRecorder = GpxRecorder(application)

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    private var trackingStarted = false

    /** Call once, after location permission has been granted. */
    fun startTracking() {
        if (trackingStarted) return
        trackingStarted = true

        viewModelScope.launch {
            locationRepository.locationUpdates(minIntervalMs = 1000L, minDistanceM = 1f)
                .collect { location -> onLocation(location) }
        }

        viewModelScope.launch {
            compassRepository.headingUpdates().collect { heading ->
                _uiState.update { it.copy(headingDeg = heading) }
            }
        }

        viewModelScope.launch {
            while (true) {
                _uiState.update { it.copy(timeText = timeFormat.format(Date())) }
                kotlinx.coroutines.delay(1000L)
            }
        }
    }

    private fun onLocation(location: Location) {
        val speedKmh = if (location.hasSpeed()) (location.speed * 3.6f).toInt() else 0
        val altitude = if (location.hasAltitude()) location.altitude.toInt() else 0

        _uiState.update {
            it.copy(
                speedKmh = speedKmh,
                altitudeM = altitude,
                latitude = location.latitude,
                longitude = location.longitude,
                hasGpsFix = true,
                gpsAccuracyM = if (location.hasAccuracy()) location.accuracy else 0f
            )
        }

        if (gpxRecorder.isRecording) {
            gpxRecorder.addPoint(location)
            _uiState.update {
                it.copy(gpxPointCount = gpxRecorder.pointsRecorded())
            }
        }
    }

    fun toggleNightMode() {
        _uiState.update { it.copy(isNightMode = !it.isNightMode) }
    }

    fun setNightMode(isNight: Boolean) {
        _uiState.update { it.copy(isNightMode = isNight) }
    }

    fun toggleGpxRecording() {
        if (gpxRecorder.isRecording) {
            val file = gpxRecorder.stop()
            _uiState.update {
                it.copy(isRecording = false, gpxFileName = file?.name)
            }
        } else {
            val file = gpxRecorder.start()
            _uiState.update {
                it.copy(isRecording = true, gpxPointCount = 0, gpxFileName = file.name)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        if (gpxRecorder.isRecording) {
            gpxRecorder.stop()
        }
    }
}
