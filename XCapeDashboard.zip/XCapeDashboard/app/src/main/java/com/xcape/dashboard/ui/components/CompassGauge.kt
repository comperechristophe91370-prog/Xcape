package com.xcape.dashboard.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xcape.dashboard.ui.theme.DashboardTheme
import kotlin.math.roundToInt

/**
 * Round compass dial: fixed heading-up needle showing current heading,
 * with N/E/S/W ticks that rotate underneath — same convention as the
 * BMW GS TFT compass widget.
 */
@Composable
fun CompassGauge(
    headingDeg: Float,
    modifier: Modifier = Modifier
) {
    val colors = DashboardTheme.colors

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(modifier = Modifier.width(96.dp).height(96.dp)) {
            val radius = size.minDimension / 2f * 0.9f
            val center = Offset(size.width / 2f, size.height / 2f)

            // Outer ring
            drawCircle(
                color = colors.dim,
                radius = radius,
                center = center,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f)
            )

            // Rotate the tick/label layer opposite to heading so it reads heading-up
            rotate(degrees = -headingDeg, pivot = center) {
                val cardinals = listOf("N" to 0f, "E" to 90f, "S" to 180f, "W" to 270f)
                cardinals.forEach { (_, angle) ->
                    rotate(degrees = angle, pivot = center) {
                        drawLine(
                            color = if (angle == 0f) colors.accent else colors.dim,
                            start = Offset(center.x, center.y - radius),
                            end = Offset(center.x, center.y - radius + 14f),
                            strokeWidth = 4f
                        )
                    }
                }
            }

            // Fixed needle pointing up (current heading)
            drawLine(
                color = colors.accent,
                start = center,
                end = Offset(center.x, center.y - radius + 20f),
                strokeWidth = 6f
            )
        }

        Text(
            text = headingToCardinal(headingDeg) + " " + headingDeg.roundToInt() + "°",
            color = colors.onSurface,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

private fun headingToCardinal(deg: Float): String {
    val dirs = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    val index = (((deg % 360) + 360) % 360 / 45f).roundToInt() % 8
    return dirs[index]
}
