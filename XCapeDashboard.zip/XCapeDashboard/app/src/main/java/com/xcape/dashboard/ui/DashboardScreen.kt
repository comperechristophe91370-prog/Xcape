package com.xcape.dashboard.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.xcape.dashboard.ui.components.CompassGauge
import com.xcape.dashboard.ui.components.GpxControlBar
import com.xcape.dashboard.ui.components.InfoBar
import com.xcape.dashboard.ui.components.OsmMapView
import com.xcape.dashboard.ui.components.SpeedGauge
import com.xcape.dashboard.ui.theme.DashboardTheme
import com.xcape.dashboard.viewmodel.DashboardUiState

/**
 * BMW-GS-TFT-inspired layout: full-bleed map in the background, a large
 * speed readout anchored bottom-left, compass top-left, info strip top,
 * and oversized glove-friendly controls bottom-right.
 */
@Composable
fun DashboardScreen(
    state: DashboardUiState,
    onToggleRecording: () -> Unit,
    onToggleNightMode: () -> Unit
) {
    val colors = DashboardTheme.colors

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        OsmMapView(
            latitude = state.latitude,
            longitude = state.longitude,
            headingDeg = state.headingDeg,
            isNightMode = state.isNightMode,
            modifier = Modifier.fillMaxSize()
        )

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            // Top info strip
            InfoBar(
                altitudeM = state.altitudeM,
                timeText = state.timeText,
                hasGpsFix = state.hasGpsFix,
                gpsAccuracyM = state.gpsAccuracyM,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 14.dp)
            )

            // Compass, top-left
            CompassGauge(
                headingDeg = state.headingDeg,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp)
            )

            // Big speed readout, bottom-left, on a translucent panel for legibility
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
                    .background(colors.surface.copy(alpha = 0.55f), RoundedCornerShape(24.dp))
            ) {
                SpeedGauge(
                    speedKmh = state.speedKmh,
                    hasFix = state.hasGpsFix,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                )
            }

            // GPX + day/night controls, bottom-right, thumb/glove reachable
            GpxControlBar(
                isRecording = state.isRecording,
                gpxPointCount = state.gpxPointCount,
                isNightMode = state.isNightMode,
                onToggleRecording = onToggleRecording,
                onToggleNightMode = onToggleNightMode,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
            )
        }
    }
}
