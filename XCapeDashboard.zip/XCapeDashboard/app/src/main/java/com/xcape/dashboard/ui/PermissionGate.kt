package com.xcape.dashboard.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.PermissionStatus
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.xcape.dashboard.ui.theme.DashboardTheme

/**
 * Blocks the dashboard until fine location is granted, since every widget
 * (speed, compass-follow, altitude, map, GPX) depends on GPS fixes.
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun PermissionGate(
    onGranted: @Composable () -> Unit
) {
    val colors = DashboardTheme.colors

    val permissionsState = rememberMultiplePermissionsState(
        permissions = listOf(
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        )
    )

    val allGranted = permissionsState.permissions.all {
        it.status == PermissionStatus.Granted
    }

    if (allGranted) {
        onGranted()
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(colors.background)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "X-Cape Dashboard needs GPS access to show speed, heading, altitude and to record GPX tracks.",
                color = colors.onSurface,
                textAlign = TextAlign.Center
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(12.dp))
            Button(onClick = { permissionsState.launchMultiplePermissionRequest() }) {
                Text("Grant location access")
            }
        }
    }
}
