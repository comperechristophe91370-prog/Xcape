package com.xcape.dashboard.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable

/**
 * Dashboard-specific color set, richer than Material's ColorScheme so every
 * gauge/widget can pull consistent day/night colors.
 */
@Immutable
data class DashboardColors(
    val background: androidx.compose.ui.graphics.Color,
    val surface: androidx.compose.ui.graphics.Color,
    val onSurface: androidx.compose.ui.graphics.Color,
    val accent: androidx.compose.ui.graphics.Color,
    val accentSecondary: androidx.compose.ui.graphics.Color,
    val warning: androidx.compose.ui.graphics.Color,
    val dim: androidx.compose.ui.graphics.Color
)

val LocalDashboardColors = androidx.compose.runtime.staticCompositionLocalOf {
    DashboardColors(
        background = DayBackground,
        surface = DaySurface,
        onSurface = DayOnSurface,
        accent = DayAccent,
        accentSecondary = DayAccentSecondary,
        warning = DayWarning,
        dim = DayDim
    )
}

@Composable
fun XCapeDashboardTheme(
    isNightMode: Boolean,
    content: @Composable () -> Unit
) {
    val dashboardColors = if (isNightMode) {
        DashboardColors(
            background = NightBackground,
            surface = NightSurface,
            onSurface = NightOnSurface,
            accent = NightAccent,
            accentSecondary = NightAccentSecondary,
            warning = NightWarning,
            dim = NightDim
        )
    } else {
        DashboardColors(
            background = DayBackground,
            surface = DaySurface,
            onSurface = DayOnSurface,
            accent = DayAccent,
            accentSecondary = DayAccentSecondary,
            warning = DayWarning,
            dim = DayDim
        )
    }

    val materialScheme = darkColorScheme(
        primary = dashboardColors.accent,
        background = dashboardColors.background,
        surface = dashboardColors.surface,
        onBackground = dashboardColors.onSurface,
        onSurface = dashboardColors.onSurface
    )

    androidx.compose.runtime.CompositionLocalProvider(
        LocalDashboardColors provides dashboardColors
    ) {
        MaterialTheme(
            colorScheme = materialScheme,
            typography = AppTypography,
            content = content
        )
    }
}

object DashboardTheme {
    val colors: DashboardColors
        @Composable
        get() = LocalDashboardColors.current
}
