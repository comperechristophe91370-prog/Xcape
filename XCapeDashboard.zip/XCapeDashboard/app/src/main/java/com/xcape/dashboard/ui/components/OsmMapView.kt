package com.xcape.dashboard.ui.components

import android.view.ViewGroup
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay

/**
 * Full-screen OpenStreetMap background, follows the current GPS fix and
 * rotates with the current heading — like the map widget on a BMW GS TFT.
 */
@Composable
fun OsmMapView(
    latitude: Double?,
    longitude: Double?,
    headingDeg: Float,
    isNightMode: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // osmdroid requires a one-time global config with a user agent / cache path.
    LaunchedEffect(Unit) {
        Configuration.getInstance().apply {
            userAgentValue = context.packageName
            osmdroidBasePath = context.getExternalFilesDir("osmdroid")
            osmdroidTileCache = context.getExternalFilesDir("osmdroid/tiles")
        }
    }

    val mapView = remember {
        MapView(context).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            controller.setZoom(17.0)
            zoomController.setVisibility(
                org.osmdroid.views.CustomZoomButtonsController.Visibility.NEVER
            )
        }
    }

    val myLocationOverlay = remember {
        MyLocationNewOverlay(GpsMyLocationProvider(context), mapView).apply {
            enableMyLocation()
            isDrawAccuracyEnabled = true
        }
    }

    DisposableEffect(lifecycleOwner) {
        mapView.overlays.add(myLocationOverlay)

        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            mapView.onDetach()
        }
    }

    // Recenter and rotate the map to follow the bike.
    LaunchedEffect(latitude, longitude) {
        if (latitude != null && longitude != null) {
            mapView.controller.animateTo(GeoPoint(latitude, longitude))
        }
    }

    LaunchedEffect(headingDeg) {
        mapView.mapOrientation = -headingDeg
    }

    LaunchedEffect(isNightMode) {
        // Simple night tint: osmdroid does not ship a dark tile set, so we
        // darken the whole map view; a CSS/tile-filter based theme could be
        // swapped in here later if a specific dark tile provider is added.
        mapView.overlayManager.tilesOverlay.setColorFilter(
            if (isNightMode) android.graphics.ColorMatrixColorFilter(
                floatArrayOf(
                    0.35f, 0f, 0f, 0f, 0f,
                    0f, 0.15f, 0f, 0f, 0f,
                    0f, 0f, 0.15f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            ) else null
        )
        mapView.invalidate()
    }

    AndroidView(
        modifier = modifier,
        factory = { mapView }
    )
}
