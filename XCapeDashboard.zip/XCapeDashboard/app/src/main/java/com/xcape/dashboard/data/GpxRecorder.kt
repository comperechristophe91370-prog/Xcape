package com.xcape.dashboard.data

import android.content.Context
import android.location.Location
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Streams incoming GPS fixes straight to a .gpx file on disk so a track
 * of any length can be recorded without holding everything in memory.
 */
class GpxRecorder(private val context: Context) {

    private var writer: BufferedWriter? = null
    private var currentFile: File? = null
    private var pointCount = 0

    val isRecording: Boolean
        get() = writer != null

    val activeFile: File?
        get() = currentFile

    private val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    private val fileNameFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    fun start(): File {
        stop()

        val dir = File(context.getExternalFilesDir(null), "GPX").apply { mkdirs() }
        val file = File(dir, "xcape_${fileNameFormat.format(Date())}.gpx")
        val bw = BufferedWriter(FileWriter(file, false))

        bw.write(
            """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<gpx version="1.1" creator="X-Cape Dashboard"
     xmlns="http://www.topografix.com/GPX/1/1"
     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
     xsi:schemaLocation="http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd">
  <trk>
    <name>X-Cape Track ${fileNameFormat.format(Date())}</name>
    <trkseg>
"""
        )
        bw.flush()

        writer = bw
        currentFile = file
        pointCount = 0
        return file
    }

    fun addPoint(location: Location) {
        val bw = writer ?: return
        val time = isoFormat.format(Date(location.time))
        val ele = if (location.hasAltitude()) location.altitude else null

        bw.write("      <trkpt lat=\"${location.latitude}\" lon=\"${location.longitude}\">\n")
        if (ele != null) {
            bw.write("        <ele>${"%.1f".format(Locale.US, ele)}</ele>\n")
        }
        bw.write("        <time>$time</time>\n")
        if (location.hasSpeed()) {
            bw.write("        <extensions><speed>${"%.2f".format(Locale.US, location.speed)}</speed></extensions>\n")
        }
        bw.write("      </trkpt>\n")
        bw.flush()
        pointCount++
    }

    fun pointsRecorded(): Int = pointCount

    fun stop(): File? {
        val file = currentFile
        writer?.let { bw ->
            runCatching {
                bw.write("    </trkseg>\n  </trk>\n</gpx>\n")
                bw.flush()
                bw.close()
            }
        }
        writer = null
        currentFile = null
        pointCount = 0
        return file
    }
}
