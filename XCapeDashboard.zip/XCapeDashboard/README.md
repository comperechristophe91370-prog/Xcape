# X-Cape Dashboard

Application Android (Kotlin + Jetpack Compose) pour le **screen mirroring** de la Moto Morini X-Cape 649, avec une interface inspirée du TFT BMW GS.

## Fonctionnalités

- **Carte OpenStreetMap** plein écran (osmdroid), suit la position GPS et pivote avec le cap.
- **Vitesse GPS** en très grand format, lisible d'un coup d'œil.
- **Compas** rotatif (cap magnétique, capteur `ROTATION_VECTOR` avec repli accéléromètre + magnétomètre).
- **Altitude** GPS et **heure** dans une barre d'info en haut de l'écran.
- **Mode jour/nuit** : palette orange/blanc haute lisibilité le jour, palette rouge (préservation de la vision nocturne) la nuit.
- **Boutons surdimensionnés** (76dp) pensés pour une utilisation avec des gants moto.
- **Enregistrement GPX** en streaming direct sur disque (pas de limite de durée liée à la RAM), fichiers stockés dans `Android/data/com.xcape.dashboard/files/GPX/`.

## Structure du projet

```
XCapeDashboard/
├── build.gradle.kts               # build racine
├── settings.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts           # dépendances du module app
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/                   # thèmes, icônes vectorielles, strings
        └── java/com/xcape/dashboard/
            ├── MainActivity.kt
            ├── data/
            │   ├── LocationRepository.kt   # GPS via LocationManager (pas de dépendance Play Services)
            │   ├── CompassRepository.kt    # cap magnétique via SensorManager
            │   └── GpxRecorder.kt          # écriture GPX en streaming
            ├── viewmodel/
            │   └── DashboardViewModel.kt
            └── ui/
                ├── DashboardScreen.kt
                ├── PermissionGate.kt
                ├── theme/                  # couleurs jour/nuit, typographie
                └── components/
                    ├── SpeedGauge.kt
                    ├── CompassGauge.kt
                    ├── OsmMapView.kt
                    ├── InfoBar.kt
                    └── GpxControlBar.kt
```

## Ouvrir et compiler le projet

1. **Android Studio** : `File > Open`, sélectionner le dossier `XCapeDashboard`.
2. Android Studio détecte l'absence de `gradle-wrapper.jar` (non fourni ici pour rester dans des fichiers texte) et propose de le régénérer automatiquement — accepter, ou lancer manuellement :
   ```bash
   gradle wrapper --gradle-version 8.7
   ```
3. Laisser Android Studio synchroniser Gradle (téléchargement d'AGP 8.5, Kotlin 1.9.24, Compose BOM 2024.06, osmdroid 6.1.20, Accompanist Permissions 0.34.0).
4. Lancer sur un appareil/émulateur avec `minSdk 26` (Android 8.0) minimum, GPS activé.

## Points d'attention

- **Pas de dépendance Google Play Services** : la géolocalisation utilise directement `android.location.LocationManager`, pour rester compatible avec des boîtiers de screen mirroring/têtes d'unité sans Play Services.
- **Écran maintenu allumé** (`FLAG_KEEP_SCREEN_ON`) et forcé en paysage, adapté à un montage sur le cockpit.
- **Tuiles OSM** : téléchargées via `INTERNET`, mises en cache localement par osmdroid (`osmdroid/tiles`) pour limiter la consommation data en usage répété sur le même trajet.
- **Mode nuit carte** : filtre colorimétrique appliqué aux tuiles (pas de fond de carte sombre dédié) ; il est possible de brancher un fournisseur de tuiles sombres (ex. CartoDB Dark Matter) dans `OsmMapView.kt` si souhaité.
- **Permissions** : l'app bloque l'accès au tableau de bord tant que la localisation précise n'est pas accordée (`PermissionGate.kt`), car toutes les jauges en dépendent.
